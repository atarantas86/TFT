// ========== TFT ASSISTANT - ITEMS BASED ==========

// Data
let ITEMS = { ad: [], ap: [], tank: [], util: [] };
let COMPS = [];
let ITEMS_MAP = {}; // id -> item info

// State
let selectedItems = new Set();

// ========== INIT ==========
async function init() {
    console.log('🚀 Loading data...');

    try {
        const res = await fetch('data/tactics_data.json');
        const data = await res.json();

        ITEMS = data.items;
        COMPS = data.comps;

        // Build items map
        ['ad', 'ap', 'tank', 'util'].forEach(type => {
            ITEMS[type].forEach(item => {
                ITEMS_MAP[item.id] = { ...item, type };
            });
        });

        console.log('✅ Loaded:', Object.keys(ITEMS_MAP).length, 'items,', COMPS.length, 'comps');

        renderItems();
        renderAllComps();
        bindEvents();
        updateRecommendations();

    } catch (error) {
        console.error('❌ Error loading data:', error);
    }
}

// ========== RENDER ITEMS ==========
function renderItems() {
    const containers = {
        ad: document.getElementById('itemsAD'),
        ap: document.getElementById('itemsAP'),
        tank: document.getElementById('itemsTank'),
        util: document.getElementById('itemsUtil')
    };

    ['ad', 'ap', 'tank', 'util'].forEach(type => {
        const container = containers[type];
        container.innerHTML = ITEMS[type].map(item => `
            <div class="item-chip ${type}" data-id="${item.id}">
                ${item.name}
            </div>
        `).join('');
    });
}

// ========== RENDER ALL COMPS ==========
function renderAllComps() {
    const list = document.getElementById('compsList');
    document.getElementById('compsCount').textContent = `${COMPS.length} compos`;

    list.innerHTML = COMPS.map(comp => {
        const bisHtml = comp.bisItems.map(id => {
            const item = ITEMS_MAP[id];
            return item ? `<span class="comp-bis-item">${item.name}</span>` : '';
        }).join('');

        return `
            <div class="comp-card">
                <div class="comp-header">
                    <span class="comp-name">${comp.name}</span>
                    <div class="comp-stats">
                        <span class="comp-tier ${comp.tier}">${comp.tier}</span>
                        <span class="comp-wr">${comp.winrate}%</span>
                    </div>
                </div>
                <div class="comp-bis">${bisHtml}</div>
            </div>
        `;
    }).join('');
}

// ========== BIND EVENTS ==========
function bindEvents() {
    // Item clicks
    document.querySelectorAll('.item-chip').forEach(chip => {
        chip.addEventListener('click', (e) => {
            const id = chip.dataset.id;

            if (e.shiftKey) {
                // Shift+click = remove
                selectedItems.delete(id);
            } else {
                // Click = toggle
                if (selectedItems.has(id)) {
                    selectedItems.delete(id);
                } else {
                    selectedItems.add(id);
                }
            }

            updateUI();
        });
    });

    // Clear button
    document.getElementById('clearItems').addEventListener('click', () => {
        selectedItems.clear();
        updateUI();
    });
}

// ========== UPDATE UI ==========
function updateUI() {
    // Update item chips
    document.querySelectorAll('.item-chip').forEach(chip => {
        chip.classList.toggle('selected', selectedItems.has(chip.dataset.id));
    });

    // Update selected panel
    const panel = document.getElementById('selectedPanel');
    const list = document.getElementById('selectedList');

    if (selectedItems.size > 0) {
        panel.classList.add('visible');
        list.innerHTML = Array.from(selectedItems).map(id => {
            const item = ITEMS_MAP[id];
            return item ? `<span class="selected-item ${item.type}">${item.name}</span>` : '';
        }).join('');
    } else {
        panel.classList.remove('visible');
    }

    // Update recommendations
    updateRecommendations();
}

// ========== UPDATE RECOMMENDATIONS ==========
function updateRecommendations() {
    const list = document.getElementById('recsList');

    if (selectedItems.size === 0) {
        list.innerHTML = '<div class="recs-empty">Sélectionne des items pour voir les recommandations</div>';
        return;
    }

    const selectedArray = Array.from(selectedItems);
    console.log('📊 Calculating scores for:', selectedArray);

    // Score each comp
    const scored = COMPS.map(comp => {
        const bisItems = comp.bisItems || [];
        const bisTotal = bisItems.length;

        // Count matches
        const matches = bisItems.filter(id => selectedItems.has(id));
        const matchCount = matches.length;
        const matchPercent = bisTotal > 0 ? Math.round((matchCount / bisTotal) * 100) : 0;

        // Score = match percent (0-100) + winrate bonus (0-20)
        // Winrate bonus: 45% = 0, 55% = 20
        const wrBonus = Math.max(0, Math.min(20, (comp.winrate - 45) * 2));
        const score = matchPercent + wrBonus;

        return {
            comp,
            matchCount,
            bisTotal,
            matchPercent,
            matches,
            score
        };
    });

    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);

    // Top 5
    const top5 = scored.slice(0, 5);

    console.log('🏆 Top 5:', top5.map(r => `${r.comp.name}: ${r.score} (${r.matchCount}/${r.bisTotal})`));

    // Render
    list.innerHTML = top5.map((rec, idx) => {
        const { comp, matchCount, bisTotal, matchPercent, matches, score } = rec;

        // Winrate class
        let wrClass = 'med';
        if (comp.winrate >= 52) wrClass = 'high';
        else if (comp.winrate < 49) wrClass = 'low';

        // BIS items HTML
        const bisHtml = comp.bisItems.map(id => {
            const item = ITEMS_MAP[id];
            if (!item) return '';
            const isMatch = matches.includes(id);
            return `<span class="rec-bis-item ${isMatch ? 'match' : ''}">${item.name}</span>`;
        }).join('');

        return `
            <div class="rec-card ${idx === 0 ? 'top' : ''}">
                <div class="rec-rank">${idx + 1}</div>
                <div class="rec-info">
                    <div class="rec-header">
                        <span class="rec-name">${comp.name}</span>
                        <span class="rec-tier ${comp.tier}">${comp.tier}</span>
                        <span class="rec-winrate ${wrClass}">${comp.winrate}% WR</span>
                    </div>
                    <div class="rec-match">
                        Match: <span class="rec-match-score">${matchCount}/${bisTotal} BIS</span>
                        → <span class="rec-match-score">${matchPercent}%</span>
                    </div>
                    <div class="rec-bis">${bisHtml}</div>
                </div>
                <div class="rec-score">
                    <div class="rec-score-value">${score}</div>
                    <div class="rec-score-label">score</div>
                </div>
            </div>
        `;
    }).join('');
}

// ========== START ==========
document.addEventListener('DOMContentLoaded', init);
